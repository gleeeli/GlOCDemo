//
//  SprayViewController.m
//  GrainEffect
//
//  Created by zhouen on 16/6/22.
//  Copyright © 2016年 zhouen. All rights reserved.
//

#import "SprayViewController.h"
@interface SprayViewController ()
@property (assign,nonatomic) BOOL               isCleared;
@property (strong,nonatomic) NSMutableArray     *cacheEmitterLayers;

@property (strong) CAEmitterLayer *fireEmitter;
@end
@implementation SprayViewController
-(void)viewDidLoad{
    [super viewDidLoad];
    self.cacheEmitterLayers = [NSMutableArray array];
    
    
    UIButton *buton = [[UIButton alloc] initWithFrame:CGRectMake(200, 80, 50, 30)];
    buton.backgroundColor = [UIColor grayColor];
    [buton setTitle:@"清除" forState:UIControlStateNormal];
    [self.view addSubview:buton];
    [buton addTarget:self action:@selector(clear) forControlEvents:UIControlEventTouchUpInside];
    
    
    UIButton *start = [[UIButton alloc] initWithFrame:CGRectMake(100, 80, 50, 30)];
    start.backgroundColor = [UIColor grayColor];
    [start setTitle:@"开始" forState:UIControlStateNormal];
    [self.view addSubview:start];
    [start addTarget:self action:@selector(start) forControlEvents:UIControlEventTouchUpInside];
    
    
    UISlider *slider = [[UISlider alloc] initWithFrame:CGRectMake(100, CGRectGetMaxY(start.frame) + 20, 200, 50)];
    slider.minimumValue = 0.0;
    slider.maximumValue = 1.0;
    [self.view addSubview:slider];
    [slider addTarget:self action:@selector(sliderDrag:) forControlEvents:UIControlEventTouchUpInside];
    
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self clear];
}

-(void)start{
    _isCleared = NO;
    UIImage *image = [UIImage imageNamed:@"DazFire"];
    [self shootFrom:self.view.center Level:100 Cells:@[image]];
}

- (void)sliderDrag:(UISlider *)slider {
    CGFloat percent = slider.value;
    
    [self setFireAmount:percent * 2.0];
//    CAEmitterLayer *emitter = self.cacheEmitterLayers[0];
//
//    for (CAEmitterCell *cell in emitter.emitterCells)
//    {
//        NSInteger num = 400 *percent;
//        NSLog(@"num:%zd",num);
//        //cell.velocity = num;
//        //cell.birthRate = 500 * percent;
//
//    }
}

- (void)shootFrom:(CGPoint)position Level:(int)level Cells:(NSArray <UIImage *>*)images; {
    if (_isCleared) return;
    CGPoint emiterPosition = position;
    // 配置发射器
    CAEmitterLayer *emitterLayer = [CAEmitterLayer layer];
    self.fireEmitter = emitterLayer;
    emitterLayer.emitterPosition = emiterPosition;
    //发射源的尺寸大小
    emitterLayer.emitterSize     = CGSizeMake(10, 0);
    //发射模式
    emitterLayer.emitterMode     = kCAEmitterLayerOutline;
    //发射源的形状
    emitterLayer.emitterShape    = kCAEmitterLayerLine;//kCAEmitterLayerPoint kCAEmitterLayerLine
    emitterLayer.renderMode      = kCAEmitterLayerAdditive;//kCAEmitterLayerAdditive(重叠更亮) kCAEmitterLayerOldestLast
    
    
    int index = rand()%[images count];
    CAEmitterCell *fireflake          = [CAEmitterCell emitterCell];
    //粒子的名字
    fireflake.name                    = @"fire";
    //粒子参数的速度乘数因子
    fireflake.birthRate               = level;
    fireflake.lifetime                = 1.0;//10 me1.0
    fireflake.lifetimeRange           = (1.0 * 0.35);
    //粒子速度
    fireflake.velocity                = -130;//400
    //粒子的速度范围
    fireflake.velocityRange           = 30;//100
    //粒子y方向的加速度分量 正数为减速
    fireflake.yAcceleration           = -200;
    //snowflake.xAcceleration = 200;
    //周围发射角度
//    snowflake.emissionRange           = 0.25*M_PI;
    //    snowflake.emissionLatitude = 200;
    fireflake.emissionLongitude       = 2*M_PI;
//    snowflake.emissionLongitude  = M_PI;
    //子旋转角度范围
//    fireflake.spinRange               = 2*M_PI;
    
    fireflake.contents                = (id)[[images objectAtIndex:index] CGImage];
//    fireflake.contentsScale           = 0.9;
//    fireflake.scale                   = 0.1;
    fireflake.scaleSpeed              = 0.3;
//    fireflake.alphaSpeed = -0.4;
    fireflake.color = [[UIColor colorWithRed:0.8 green:0.4 blue:0.2 alpha:0.1] CGColor];
//    fireflake.color = [UIColor colorWithRed:1.0 green:0.6 blue:0 alpha:1].CGColor;
//    snowflake.greenRange        = 0.3;        // different colors//一个粒子的颜色green 能改变的范围
//    snowflake.redRange            = 0.3;//一个粒子的颜色red 能改变的范围
    //snowflake.blueRange        = 1.0;//一个粒子的颜色blue 能改变的范围
    
    CAEmitterCell * spark1 = [CAEmitterCell emitterCell];
    spark1.birthRate            = 5.0;
    spark1.velocity             = -80;
    spark1.velocityRange        = 30;
    fireflake.yAcceleration           = -300;
    spark1.emissionRange        = 2 * M_PI;    // 360 度
    spark1.lifetime            = 0.35;
    spark1.lifetimeRange = (0.35 * 0.35);
    spark1.contents            = (id) [[UIImage imageNamed:@"FFRing"] CGImage];
    spark1.scale = 0.5;
    spark1.scaleSpeed        = -0.8;
//    spark1.scaleSpeed        = 1.3;
    spark1.alphaSpeed        = -.9;
    spark1.spin                = M_PI_2;
    spark1.spinRange            = M_PI_2;
    spark1.color = [UIColor colorWithRed:1.0 green:0 blue:0 alpha:1.0].CGColor;
    
    emitterLayer.emitterCells  = [NSArray arrayWithObject:fireflake];
    fireflake.emitterCells = [NSArray arrayWithObject:spark1];
    [self.cacheEmitterLayers addObject:emitterLayer];
    
    [self.view.layer addSublayer:emitterLayer];
    
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        if (_isCleared)return ;
//        emitterLayer.birthRate = 0;
//        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//            if (_isCleared)return ;
//            [emitterLayer removeFromSuperlayer];
//            [self.cacheEmitterLayers removeObject:emitterLayer];
//        });
//    });
    
}

-(void)clear{
    self.isCleared = YES;
    for (CAEmitterLayer *emitterLayer in self.cacheEmitterLayers)
    {
        [emitterLayer removeFromSuperlayer];
        emitterLayer.emitterCells = nil;
    }
    [self.cacheEmitterLayers removeAllObjects];
}

- (void) setFireAmount:(float)zeroToOne
{
    // Update the fire properties
    [self.fireEmitter setValue:[NSNumber numberWithInt:(zeroToOne * 100)]
                    forKeyPath:@"emitterCells.fire.birthRate"];
    [self.fireEmitter setValue:[NSNumber numberWithFloat:zeroToOne]
                    forKeyPath:@"emitterCells.fire.lifetime"];
    [self.fireEmitter setValue:[NSNumber numberWithFloat:(zeroToOne * 0.35)]
                    forKeyPath:@"emitterCells.fire.lifetimeRange"];
    self.fireEmitter.emitterSize = CGSizeMake(10 * zeroToOne, 0);
//    [self.fireEmitter setValue:[NSNumber numberWithFloat:(zeroToOne * -200)]
//                    forKeyPath:@"emitterCells.fire.yAcceleration"];
    
//    [self.smokeEmitter setValue:[NSNumber numberWithInt:zeroToOne * 4]
//                     forKeyPath:@"emitterCells.smoke.lifetime"];
//    [self.smokeEmitter setValue:(id)[[UIColor colorWithRed:1 green:1 blue:1 alpha:zeroToOne * 0.3] CGColor]
//                     forKeyPath:@"emitterCells.smoke.color"];
}


#pragma 第二种
- (void)shoot2From:(CGPoint)position Level:(int)level Cells:(NSArray <UIImage *>*)images; {
    if (_isCleared) return;
    CGPoint emiterPosition = position;
    // 配置发射器
    CAEmitterLayer *emitterLayer = [CAEmitterLayer layer];
    self.fireEmitter = emitterLayer;
    emitterLayer.emitterPosition = emiterPosition;
    //发射源的尺寸大小
    emitterLayer.emitterSize     = CGSizeMake(10, 0);
    //发射模式
    emitterLayer.emitterMode     = kCAEmitterLayerOutline;
    //发射源的形状
    emitterLayer.emitterShape    = kCAEmitterLayerLine;//kCAEmitterLayerPoint kCAEmitterLayerLine
    emitterLayer.renderMode      = kCAEmitterLayerAdditive;//kCAEmitterLayerAdditive(重叠更亮) kCAEmitterLayerOldestLast
    
    
    int index = rand()%[images count];
    CAEmitterCell *fireflake          = [CAEmitterCell emitterCell];
    //粒子的名字
    fireflake.name                    = @"fire";
    //粒子参数的速度乘数因子
    fireflake.birthRate               = level;
    fireflake.lifetime                = 1.0;//10 me1.0
    fireflake.lifetimeRange           = (1.0 * 0.35);
    //粒子速度
    fireflake.velocity                = -80;//400
    //粒子的速度范围
    fireflake.velocityRange           = 30;//100
    //粒子y方向的加速度分量 正数为减速
    fireflake.yAcceleration           = -200;
    //snowflake.xAcceleration = 200;
    //周围发射角度
    //    snowflake.emissionRange           = 0.25*M_PI;
    //    snowflake.emissionLatitude = 200;
    fireflake.emissionLongitude       = 2*M_PI;
    //    snowflake.emissionLongitude  = M_PI;
    //子旋转角度范围
    //    fireflake.spinRange               = 2*M_PI;
    
    fireflake.contents                = (id)[[images objectAtIndex:index] CGImage];
    //    fireflake.contentsScale           = 0.9;
    fireflake.scale                   = 0.1;
    fireflake.scaleSpeed              = 0.1;
    fireflake.alphaSpeed = -0.4;
    fireflake.color = [[UIColor colorWithRed:0.8 green:0.4 blue:0.2 alpha:0.5] CGColor];
    //    fireflake.color = [UIColor colorWithRed:1.0 green:0.6 blue:0 alpha:1].CGColor;
    //    snowflake.greenRange        = 0.3;        // different colors//一个粒子的颜色green 能改变的范围
    //    snowflake.redRange            = 0.3;//一个粒子的颜色red 能改变的范围
    //snowflake.blueRange        = 1.0;//一个粒子的颜色blue 能改变的范围
    
    CAEmitterCell * spark1 = [CAEmitterCell emitterCell];
    spark1.birthRate            = 3.0;
    spark1.velocity            = 10;
    spark1.velocityRange = 10;
    spark1.emissionRange        = 2* M_PI;    // 360 度
    spark1.lifetime            = 1.35;
    spark1.lifetimeRange = (1.35 * 0.35);
    spark1.contents            = (id) [[UIImage imageNamed:@"FFRing"] CGImage];
    spark1.scaleSpeed        = -0.8;
    spark1.alphaSpeed        = -.9;
    spark1.spin                = M_PI_2;
    spark1.spinRange            = M_PI_2;
    spark1.color = [UIColor colorWithRed:1.0 green:0 blue:0 alpha:1.0].CGColor;
    
    emitterLayer.emitterCells  = [NSArray arrayWithObject:fireflake];
    //    fireflake.emitterCells = [NSArray arrayWithObject:spark1];
    [self.cacheEmitterLayers addObject:emitterLayer];
    
    [self.view.layer addSublayer:emitterLayer];
    
    //    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //        if (_isCleared)return ;
    //        emitterLayer.birthRate = 0;
    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //            if (_isCleared)return ;
    //            [emitterLayer removeFromSuperlayer];
    //            [self.cacheEmitterLayers removeObject:emitterLayer];
    //        });
    //    });
    
}
@end
